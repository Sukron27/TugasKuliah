// setiap di resize halaman akan reload, soalnya untuk memperbarui pengambilan width gambar pada carousel
window.onresize = function(){
    location.reload();
}
// browser.devtools.inpectedWindow.reload();

/* Script untuk menambahkan class active pada link yang di klik */
const links = document.querySelectorAll('ul li a'); // ambil elemen
// looping elemen, karena berbentuk nodelist
for(let link of links){
    // beri event handler setiap link
    link.addEventListener('click', function(){
        // ambil class active yang sekarang
        let current = document.getElementsByClassName('active'); 
        console.log(current);
        // jika ditemukan lagi class active berikutnya
        if(current.length > 0){
            // hapus class active yang pertama
            current[0].classList.remove('active');
        }
        // perbarui class active
        link.classList.add('active');
    });
}

/* === script untuk navigasi, apabila di scrool melebihi ukuran article#home === */
const nav = document.getElementsByTagName('nav'); // ambil elemen nav dengan dom
const home = document.getElementById('home').offsetHeight; // ambil size article #home(include padding)
// tambhakan event handler
window.onscroll = function(){
    // cek jika body/html discroll > ukuran home
    if(document.body.scrollTop > home || document.documentElement.scrollTop > home){
        // set style ini:
        nav[0].style.backgroundColor = "#fff";
        nav[0].style.borderBottom = "1px solid #f4f4f5";
    }
    // jika tidak
    else{
        // set style ini:
        nav[0].style.backgroundColor = "#ffc831";
        nav[0].style.border = "none";
    }
}


/* ======================= Hamburger button ======================= */
const Hamburger = document.querySelector('.hamburger');
const spans = Hamburger.getElementsByTagName('span');
const myLinks = document.querySelector('.links');

Hamburger.addEventListener('click', function(){
    Hamburger.classList.toggle('open');
    if(Hamburger.classList.contains('open')){
        myLinks.classList.add('wrap');
    }else{
        myLinks.classList.remove('wrap');
    }
});

/*===== Script untuk toggle aside owner====== */
const btn_toggler = document.querySelector('.btn-toggler'); // tombol toggler(gambar +)
const cont_toggler = document.querySelector('.toggler'); // container toggler
const aside = document.getElementsByTagName('aside')[0]; // ambil element aside, karena html collection kasi index

btn_toggler.addEventListener('click', function(){
    // toggle class spawn, klo ada hapus, klo tidak ada tmbahkan
    aside.classList.toggle('spawn');
    if(aside.classList.contains('spawn')){
        // kalo class spawan ada, set:
        cont_toggler.style.border = "none";
    }else{
        // jika tidak, set:
        cont_toggler.style.borderBottom = "1px solid #e1e1e4";
    }
})


/* =====script untuk gambar promo-utama, jika di hover ====*/
const banner = document.querySelector('.banner-promo .container');
const image_banner = banner.getElementsByTagName('img')[0];

banner.addEventListener('mouseover', textIn);
banner.addEventListener('mouseout', textOut);
function textOut(){
    image_banner.style.opacity = "1";
    banner.childNodes[3].style.opacity = '0';
}

function textIn(){
    image_banner.style.opacity = "0.3";
    banner.childNodes[3].style.opacity = '1';
}


/* ======================= Carousel ======================= */
// ambil elemen html dengan dom
const container_image = document.querySelectorAll('.container-image');
const buttons = document.querySelectorAll('.control');
const images = [];
const widthImg = document.querySelectorAll('.visible-image');

for(let i=0; i<container_image.length; i++){
    images[i] = container_image[i].querySelectorAll('.img');
    buttons[i].addEventListener('click', Carousel(container_image[i], buttons[i], images[i], widthImg[i].clientWidth));
}

function Carousel(container_image, button, images, Width){
    let index = 0;
    let geser = 0;
    let totalImages = images.length;

    // tambahkan event handle pada masing" button
    button.addEventListener('click', function(event){
        // event elemen yang di targetkan
        const target = event.target;

        // jika button yang ditargekan mengandung class prev:
        if(target.classList.contains('prev')){
            // cek, jika index nya tidak sama dengan 0, kurangi indexnya
            if(index != 0){
                index--;
                // tambahkan nilai geser sebanyak width dari image
                geser += Width;
            }
        }
        else{ // jika button yang ditargekan mengandung class next
            // cek, jika index nya tidak sama dengan 0, tambhkan indexnya
            if(index != totalImages-1){
                    index++;
                    // kurangi nilai geser sebanyak width dari image
                    geser -= Width;
            }
        }

        // geser container_carousel ke slide(Itemcarousel) berikutnya
        // dengan memberikan properti transform: translateX(sebanyak let geser)
        container_image.style.transform = `translateX(${geser}px)`;
    })
}




